import bpy,math,random,json
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parents[1];random.seed(22)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.name='01 • CASE 002 ANIMATION';s.frame_start=1;s.frame_end=2400;s.render.fps=24
s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100
s.display.render_aa='FXAA';sh=s.display.shading;sh.light='STUDIO';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.3;sh.curvature_valley_factor=.7;sh.cavity_ridge_factor=1.2;sh.cavity_valley_factor=1.0;sh.show_specular_highlight=True;sh.background_type='WORLD';s.world.color=(.018,.035,.055)
bpy.context.preferences.studio_lights.load(str(P/'SCRIPTS/case02.sl'),'STUDIO');sh.studio_light='case02.sl';sh.studiolight_rotate_z=.15
s.view_settings.view_transform='Standard';s.view_settings.look='Medium High Contrast' if 'Medium High Contrast' in [i.name for i in s.bl_rna.properties] else 'None'
def mat(n,c,rough=.6):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Roughness'].default_value=rough;return m
M={k:mat(k,c) for k,c in {'ink':(.016,.025,.041),'wall':(.045,.085,.12),'stone':(.11,.19,.22),'road':(.045,.085,.11),'metal':(.095,.17,.19),'cream':(.82,.75,.58),'skin':(.69,.40,.25),'hair':(.025,.032,.047),'white':(.9,.88,.77),'orange':(1,.42,.075),'amber':(.9,.24,.025),'light':(1,.77,.38),'water':(.07,.19,.24),'glass':(.045,.12,.17),'teal':(.13,.55,.6),'red':(.5,.12,.06),'sole':(.055,.065,.08)}.items()}
def meshmat(o,m):o.data.materials.append(M[m] if isinstance(m,str) else m);return o
def cube(n,loc,dim,m,bevel=0,parent=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);meshmat(o,m)
 if bevel:q=o.modifiers.new('Rounded edges','BEVEL');q.width=bevel;q.segments=3;o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
 if parent:o.parent=parent
 return o
def ball(n,loc,scale,m,parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=10,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;meshmat(o,m)
 for q in o.data.polygons:q.use_smooth=True
 if parent:o.parent=parent
 return o
def empty(n,loc=(0,0,0),parent=None):
 o=bpy.data.objects.new(n,None);s.collection.objects.link(o);o.location=loc;o.empty_display_type='PLAIN_AXES';o.empty_display_size=.13;o.parent=parent;return o
def rod(n,a,b,r,m,parent=None):
 a,b=Vector(a),Vector(b);o=ball(n,(a+b)/2,(r,r,(a-b).length/2+r*.2),m,parent);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def orient(o,a,b,r):
 a,b=Vector(a),Vector(b);o.location=(a+b)/2;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();o.scale=(r,r,(a-b).length/2+r*.2)
def curve(n,pts,r,m,parent=None):
 c=bpy.data.curves.new(n,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=2;p=c.splines.new('POLY');p.points.add(len(pts)-1)
 for v,co in zip(p.points,pts):v.co=(*co,1)
 o=bpy.data.objects.new(n,c);s.collection.objects.link(o);meshmat(o,m);o.parent=parent;return o
def text(n,body,loc,size,m,rot=(math.pi/2,0,0)):
 c=bpy.data.curves.new(n,'FONT');c.body=body;c.align_x='CENTER';c.size=size;c.extrude=.001;o=bpy.data.objects.new(n,c);s.collection.objects.link(o);o.location=loc;o.rotation_euler=rot;meshmat(o,m);return o
def polygon(n,pts,m):
 me=bpy.data.meshes.new(n);me.from_pydata(pts,[],[list(range(len(pts)))]);me.update();o=bpy.data.objects.new(n,me);s.collection.objects.link(o);meshmat(o,m);return o
def key(o,f):
 for field in ['location','rotation_euler','scale']:o.keyframe_insert(field,frame=f)
def smooth(a,b,t):
 t=max(0,min(1,t));return a+(b-a)*t*t*(3-2*t)
def track(t,keys):
 if t<=keys[0][0]:return keys[0][1]
 for (a,x),(b,y) in zip(keys,keys[1:]):
  if t<=b:
   w=max(0,min(1,(t-a)/(b-a)));w=w*w*(3-2*w)
   if isinstance(x,(list,tuple)):return tuple(u+(v-u)*w for u,v in zip(x,y))
   return x+(y-x)*w
 return keys[-1][1]
# Rain-soaked station entrance: layers, small bevels, warm practicals.
cube('Street foundation',(0,2,-.14),(22,28,.24),'road')
for ix in range(-7,8):
 for iy in range(-4,11):
  if abs(ix)<2 and 0<=iy<3:continue
  cube('Paving slab',(ix*.77,iy*.9,-.003),(.752,.883,.035),'road',.008)
cube('Station back wall',(0,3.6,2.8),(9,.32,5.6),'wall',.06)
for x in [-4.4,-2.1,2.1,4.4]:
 cube('Pilaster',(x,3.34,2.55),(.28,.3,5.1),'stone',.03)
for z in [.2,3.8,5.1]:cube('Masonry band',(0,3.35,z),(9,.17,.17),'stone',.02)
# Mirror booth is an open stage with an independent actor, bordered by actual glass details.
cube('Mirror backing',(0,3.32,1.6),(2.55,.05,3.2),'glass',.03)
for x in [-1.33,1.33]:
 cube('Mirror brass frame',(x,2.1,1.66),(.12,.18,3.32),'amber',.035)
 cube('Mirror fine highlight',(x-.025,1.998,1.66),(.025,.01,3.23),'light',.006)
for z in [.03,3.32]:cube('Mirror frame rail',(0,2.1,z),(2.75,.18,.12),'amber',.025)
cube('Mirror ceiling',(0,2.67,3.37),(2.8,1.4,.12),'metal',.03)
cube('Mirror inner floor',(0,2.65,.02),(2.5,1.35,.04),'water',.01)
text('Mirror heading','LAST TRAIN',(0,1.98,3.58),.23,'cream')
text('Mirror serial','02 / NORTHBOUND',(0,1.99,.2),.085,'teal')
# Edge streaks suggest glass without hiding the face or introducing a second physical reflection.
for x in [-1.2,1.18]:
 for j in range(4):curve('Glass edge streak',[(x,2.0,.55+j*.6),(x-.07,2.0,.95+j*.6)],.004,'teal')
for x in [-3.3,3.3]:
 cube('Shop window surround',(x,3.12,1.9),(1.55,.12,2.6),'ink',.06)
 for dx in [-.4,.4]:
  for z in [1.2,2.4]:cube('Amber shop panes',(x+dx,3.03,z),(.68,.025,1.06),'light',.02)
 cube('Awning',(x,2.8,3.35),(1.9,.9,.15),'metal',.04)
 for j in range(7):cube('Awning ribs',(x-.8+j*.27,2.72,3.44),(.025,.75,.025),'stone')
text('Shop sign','NIGHT OFFICE',(-3.3,2.98,3.8),.15,'cream')
text('Street address','BUREAU / 02',(3.3,2.98,3.8),.14,'cream')
# Street depth on either side of the facade.
for side in [-1,1]:
 for j in range(6):
  x=side*(5.2+j*.35);y=4+j*3;h=6+j*.7
  cube('Distant architecture',(x,y,h/2),(2.4,2.8,h),'wall',.06)
  for z in [1.5,3.1,4.7]:
   for dx in [-.55,.3]:cube('Distant window',(x+dx,y-1.42,z),(.45,.02,.75),'amber',.01)
# benches, drain, pipes and lamp kept clear of all principal shot lines.
for x in [-3,3]:
 for z in [.45,.62]:cube('Bench slat',(x,1.0,z),(1.3,.35,.11),'metal',.03)
 for dx in [-.48,.48]:rod('Bench leg',(x+dx,1,.02),(x+dx,1,.55),.045,'ink')
for j in range(14):cube('Drain slot',(2.8,-1.3+j*.055,.02),(.45,.02,.012),'ink')
for x in [-4.5,4.5]:
 rod('Drainpipe',(x,3.06,.1),(x,3.06,5.1),.045,'metal')
 for z in [1,3,4.5]:cube('Pipe collar',(x,3.06,z),(.15,.12,.045),'stone',.01)
for x,y in [(-4,-1),(4,1),(-5,7),(5,8)]:
 rod('Lamp post',(x,y,0),(x,y,4.2),.06,'metal')
 rod('Lamp arm',(x,y,4.2),(x*.83,y,4.2),.05,'metal')
 cube('Lamp housing',(x*.83,y,4.16),(.45,.32,.13),'ink',.06)
 cube('Lamp lit underside',(x*.83,y,4.07),(.36,.25,.018),'light',.02)
# Flat irregular puddles, without the raised pebble-like forms of CASE 001.
for i in range(28):
 x=random.uniform(-5,5);y=random.uniform(-5,3)
 if abs(x)<1.5 and y>-.9:continue
 rx=random.uniform(.15,.65);ry=random.uniform(.1,.32)
 pts=[(x+math.cos(j*math.tau/18)*rx*(1+.12*math.sin(j*3)),y+math.sin(j*math.tau/18)*ry,.022) for j in range(18)]
 polygon('Flat rainwater',pts,'water')
# Reflected warm light streaks break up the wet surface.
for x in [-3.3,3.3]:
 for j in range(10):cube('Window reflection streak',(x+random.uniform(-.3,.3),2-j*.42,.026),(random.uniform(.1,.45),.028,.003),'amber')
# The far backdrop ensures no empty gray horizon in camera cuts.
cube('Night sky',(0,24,7),(60,.3,30),'ink')
# Reusable articulated character with separately editable control objects.
class Person:
 def __init__(self,name):
  self.name=name;self.root=empty(name+' / ROOT');self.body=empty(name+' / breathing torso',(0,0,0),self.root);self.head=empty(name+' / HEAD',(0,0,2.02),self.body)
  cube(name+' jacket',(0,0,1.34),(.65,.37,.78),'cream',.13,self.body)
  ball(name+' jacket shoulder',(0,0,1.66),(.36,.205,.16),'cream',self.body)
  cube(name+' hem',(0,0,.98),(.67,.38,.09),'cream',.035,self.body)
  cube(name+' shirt',(0,-.198,1.62),(.16,.026,.25),'stone',.015,self.body)
  for x in [-.12,.12]:
   o=cube(name+' folded collar',(x,-.22,1.66),(.15,.045,.24),'cream',.025,self.body);o.rotation_euler.y=(-1 if x<0 else 1)*.35
  for z in [1.17,1.35,1.51]:ball(name+' button',(.025,-.204,z),(.022,.012,.022),'metal',self.body)
  for x in [-.2,.2]:cube(name+' pocket',(x,-.202,1.18),(.17,.025,.16),'cream',.02,self.body)
  # Eye shapes are inset and proportioned more subtly than the first episode.
  ball(name+' face',(0,0,0),(.29,.24,.34),'skin',self.head)
  for x in [-.29,.29]:ball(name+' ear',(x,.015,-.035),(.064,.055,.1),'skin',self.head)
  ball(name+' hair crown',(0,.035,.22),(.3,.245,.19),'hair',self.head)
  random.seed(12)
  for j in range(8):
   o=ball(name+' swept hair',(-.23+j*.065,-.16,.23+random.uniform(-.03,.05)),(.075,.115,.15),'hair',self.head);o.rotation_euler.y=-.3
  self.eyes=[];self.pupils=[];self.brows=[]
  for x in [-.105,.105]:
   e=ball(name+' eye socket',(x,-.226,.015),(.071,.029,.068),'white',self.head);self.eyes.append(e)
   q=ball(name+' iris',(x,-.25,.012),(.034,.013,.044),'hair',self.head);self.pupils.append(q)
   ball(name+' eye glint',(x-.008,-.264,.027),(.009,.004,.012),'white',self.head)
   b=cube(name+' brow',(x,-.235,.118),(.135,.026,.025),'hair',.01,self.head);self.brows.append(b)
  ball(name+' nose',(0,-.249,-.075),(.047,.045,.051),'skin',self.head)
  self.mouth=curve(name+' mouth',[(-.071,-.218,-.18),(-.035,-.235,-.19),(0,-.24,-.195),(.035,-.235,-.19),(.071,-.218,-.18)],.012,'hair',self.head)
  self.surprise=ball(name+' gasp',(0,-.232,-.19),(.035,.012,.05),'hair',self.head)
  self.bag=empty(name+' / BAG',(0,0,0),self.body)
  cube(name+' shoulder satchel',(.39,.03,1.07),(.25,.3,.4),'hair',.06,self.bag)
  cube(name+' bag flap',(.39,-.13,1.14),(.23,.035,.22),'metal',.04,self.bag)
  cube(name+' brass buckle',(.39,-.153,1.12),(.045,.02,.06),'amber',.01,self.bag)
  curve(name+' shoulder strap',[(-.24,-.18,1.78),(0,-.245,1.45),(.37,-.19,1.08)],.025,'hair',self.body)
  self.arms=[];self.legs=[];self.animated=[self.root,self.body,self.head,self.bag,self.mouth,self.surprise]+self.eyes+self.pupils+self.brows
  for side in [-1,1]:
   upper=ball(name+' sleeve upper',(0,0,0),(1,1,1),'cream',self.body);lower=ball(name+' sleeve lower',(0,0,0),(1,1,1),'cream',self.body)
   hand=empty(name+' / HAND '+str(side),(0,0,0),self.body)
   ball(name+' palm',(0,0,0),(.075,.055,.1),'skin',hand)
   fingers=[]
   for j in range(4):
    q=ball(name+' finger',((j-1.5)*.032,-.005,-.11),(.019,.025,.065),'skin',hand);fingers.append(q)
   q=ball(name+' thumb',(-side*.077,-.015,-.035),(.025,.03,.065),'skin',hand);q.rotation_euler.y=side*.6
   joint=ball(name+' elbow',(0,0,0),(.1,.1,.1),'cream',self.body)
   self.arms.append((upper,lower,hand,fingers,joint));self.animated += [upper,lower,hand,joint]+fingers
   upper=ball(name+' upper leg',(0,0,0),(1,1,1),'hair',self.root);lower=ball(name+' lower leg',(0,0,0),(1,1,1),'hair',self.root)
   foot=empty(name+' / FOOT '+str(side),(0,0,0),self.root)
   cube(name+' boot',(0,-.075,.1),(.24,.38,.18),'hair',.055,foot);cube(name+' sole',(0,-.075,.025),(.25,.39,.055),'sole',.025,foot)
   for yy in [-.12,-.07,-.02]:rod(name+' boot lace',(-.055,yy,.198),(.055,yy,.198),.008,'stone',foot)
   joint=ball(name+' knee',(0,0,0),(.108,.108,.108),'hair',self.root)
   self.legs.append((upper,lower,foot,joint));self.animated += [upper,lower,foot,joint]
 def pose(self,t,f,loc,turn,walk=0,gesture=0,look=0,emotion=0,palms=False,visible=True):
  self.root.location=loc;self.root.rotation_euler.z=turn;self.root.scale=(1,1,1) if visible else (0,0,0)
  phase=t*math.tau*1.35
  self.body.location.z=.009*math.sin(t*2.2)+abs(math.sin(phase))*.022*walk
  self.body.rotation_euler=(.025*walk,math.sin(phase)*.025*walk,.025*math.sin(t*1.1))
  self.head.rotation_euler=(.04+emotion*.08,.035*math.sin(t*1.3),look)
  self.bag.rotation_euler.y=math.sin(phase+.6)*.05*walk
  blink=1
  for bt in [3.4,9.8,14,20.2,27.8,34.2,42.4,49.8,55.5,62.2,69.4,74.7,79.8,86.4,90]:
   q=abs(t-bt)
   if q<.12:blink=min(blink,.07+.93*q/.12)
  for j,(e,p,b) in enumerate(zip(self.eyes,self.pupils,self.brows)):
   e.scale.z=.068*blink;p.scale.z=.044*blink;p.location.x=(-.105 if j==0 else .105)+look*.035
   b.location.z=.118+emotion*.055;b.rotation_euler.y=(-1 if j==0 else 1)*emotion*.18
  self.mouth.scale.z=1-emotion*.4;self.surprise.scale=(.035,.012,.05) if emotion>.7 else (.0001,.0001,.0001)
  for j,side in enumerate([-1,1]):
   sw=math.sin(phase+j*math.pi)*walk
   upper,lower,foot,knee=self.legs[j]
   # Foot motion has a flat planted half-cycle and a lifted recovery half-cycle.
   foot.location=(side*.175,sw*.18,max(0,math.cos(phase+j*math.pi))*.12*walk)
   hip=Vector((side*.17,0,.98));ank=Vector(foot.location)+Vector((0,0,.16));mid=(hip+ank)/2;mid.y-=.045+max(0,math.cos(phase+j*math.pi))*.13*walk
   knee.location=mid;orient(upper,hip,mid,.125);orient(lower,mid,ank,.102)
   upper,lower,hand,fingers,joint=self.arms[j]
   shoulder=Vector((side*.36,0,1.64));rest=Vector((side*.46,sw*.14,1.03))
   target=Vector((side*.43,-.38,1.8)) if palms else Vector((side*.5,-.15,2.14))
   g=gesture if (j==1 or palms) else 0
   wrist=rest.lerp(target,g);elbow=(shoulder+wrist)/2+Vector((side*.07,.02,-.08*(1-g)))
   joint.location=elbow;orient(upper,shoulder,elbow,.115);orient(lower,elbow,wrist,.095);hand.location=wrist
   hand.rotation_euler=(math.pi*g*.85,0,-side*.12*g)
   for k,q in enumerate(fingers):q.rotation_euler.x=math.sin(t*3+k*.15)*.12*g
  for o in self.animated:key(o,f)
hero=Person('WITNESS');other=Person('REFLECTION')
# Matte contact shadows are physically attached to feet; never stand in for the reflection.
# Contact shadows are rendered by the studio lighting.
# Animated actions: anticipation, response, hand tests, looking back, then the exchange.
for f in range(1,2209,3):
 t=(f-1)/24
 loc=track(t,[(0,(0,.25,0)),(1.1,(0,.25,0)),(5.5,(-1.5,-1.2,0)),(8,(-1.5,-1.2,0)),(11.5,(0,.1,0)),(26,(0,.1,0)),(30,(0,1.6,0)),(36,(0,1.6,0)),(39,(0,.1,0)),(43,(0,-.25,0)),(48,(0,-.25,0)),(54,(0,-.25,0)),(57,(0,-.25,0)),(69,(0,-.25,0)),(73,(-.6,-.4,0)),(83.8,(-.6,-.4,0)),(84,(0,2.6,.04)),(92,(0,2.6,.04))])
 turn=track(t,[(0,.4),(1,0),(5.5,0),(7.5,math.pi),(39,math.pi),(43,math.pi),(46.5,math.tau),(51.5,math.tau),(55,math.pi),(70,math.pi),(75,math.pi/2),(83.8,math.pi/2),(84,0),(92,0)])
 walk=1 if (1.1<t<5.5 or 8<t<11.5 or 26<t<30 or 36<t<39 or 70<t<73) else 0
 gest=track(t,[(0,0),(13,0),(14,1),(16,1),(17,0),(26,0),(30,.95),(36,.95),(39,0),(83.8,0),(84.5,.95),(92,.95)])
 look=track(t,[(0,0),(5,.0),(6,-.5),(7,-.5),(8,0),(41,0),(44,-.45),(48,.45),(52,0),(70,-.4),(73,0),(85,0),(87,-.25),(89,.25),(92,0)])
 hero.pose(t,f,loc,turn,walk,gest,look,emotion=.8 if 70<t<92 else .3,palms=t>=84)
 oloc=track(t,[(0,(0,2.6,.04)),(27,(0,2.6,.04)),(30,(0,2.38,.04)),(36,(0,2.38,.04)),(39,(0,2.6,.04)),(57,(0,2.6,.04)),(69.9,(0,2.6,.04)),(70,(1.1,-.25,0)),(83.8,(1.1,-.25,0)),(84,(-.6,-.4,0)),(85,(-.6,-.4,0)),(91,(-2.6,-4,0)),(92,(-2.6,-4,0))])
 oturn=track(t,[(0,0),(69.9,0),(70,-math.pi/2),(83.8,-math.pi/2),(84,.2),(92,.2)])
 og=track(t,[(0,0),(18,0),(19,1),(21,1),(22,0),(24,.75),(25,.3),(26,.75),(27,.3),(28,.95),(35,.95),(38,0),(70,0),(75,.5),(77,0),(92,0)])
 other.pose(t+1.3,f,oloc,oturn,1 if 85<t<91 else 0,og,look=-.08,emotion=0,palms=28<t<36,visible=not (57<=t<70))
# Surface ripples on glass; explicit animated geometry, kept clear of eye lines.
for j in range(5):
 pts=[(.4+math.cos(a*math.tau/64)*.28,1.98,1.78+math.sin(a*math.tau/64)*.28) for a in range(65)]
 o=curve('Amber glass ripple '+str(j),pts,.008,'orange')
 for f in range(1,2209,3):
  t=(f-1)/24;v=0
  if 30<t<39:v=((t-30-j*.27)%1.8)/1.8
  o.scale=(v*2.8,v*2.8,v*2.8) if v else (0,0,0)
  # Scaling about the centre of the interaction rather than the world origin.
  o.location=(.4*(1-o.scale.x),1.98*(1-o.scale.y),1.78*(1-o.scale.z));key(o,f)
# Lettering appears on the mirror as a warning, readable in the close shot.
warning=text('Warning on glass','DO NOT\nTURN AROUND.',(0,1.97,2.63),.16,'light')
for f,v in [(1,0),(960,0),(961,1),(1368,1),(1369,0)]:warning.scale=(v,v,v);key(warning,f)
# The station clock holds the episode's circular evidence motif.
clock=ball('Station clock face',(2.0,3.0,4.55),(.35,.04,.35),'cream')
for j in range(12):
 a=j*math.tau/12;ball('Clock mark',(2+math.sin(a)*.29,2.95,4.55+math.cos(a)*.29),(.012,.008,.012),'ink')
rod('Clock hour',(2,2.93,4.55),(1.86,2.93,4.66),.014,'ink');rod('Clock minute',(2,2.93,4.55),(2.05,2.93,4.82),.01,'ink')
# Editable practical lights for Cycles/Eevee versions.
for loc,power,col,size in [((-3,-3,6),1200,(1,.55,.24),5),((3,-2,5),800,(.25,.6,1),4),((0,2,3),250,(1,.3,.05),2)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.color=col;o.data.size=size;o.rotation_euler=(Vector((0,1,1.5))-o.location).to_track_quat('-Z','Y').to_euler()
# Defined, reviewable shot list. Target coordinates are chosen around actual actor positions.
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='DIRECTOR CAMERA';s.camera=cam;cam.data.lens=43
shots=[
(0,8,(4,-7,3.4),(3.7,-6.8,3.2),(-.4,.65,1.3),38),
(8,13,(-3,-5,3),(-2.7,-4.8,2.8),(0,1.1,1.45),40),
(13,18,(2.4,-3.5,2.65),(2.2,-3.2,2.6),(0,1.1,1.65),42),
(18,23,(-2.5,-2.6,2.8),(-2.2,-2.3,2.7),(0,2.35,1.75),48),
(23,28,(1.9,-2.4,2.7),(1.6,-2.1,2.65),(0,2.5,1.95),52),
(28,36,(-1.8,-2.2,2.65),(-1.6,-2,2.6),(.1,1.7,1.7),45),
(36,40,(2,-2.5,2.7),(2,-2.3,2.7),(0,1.2,1.8),50),
(40,46,(.7,-1.5,3),(.65,-1.3,2.95),(0,2.15,2.25),48),
(46,52,(.5,-2.9,2.55),(.3,-2.6,2.5),(0,-.2,1.9),58),
(52,57,(-4,-4.5,4),(-4.3,-4.7,4.1),(0,-.2,1.4),36),
(57,64,(1.8,-3.5,2.8),(1.5,-3.2,2.7),(0,2.4,1.7),45),
(64,70,(2.5,-3.5,2.8),(2.2,-3.2,2.7),(0,.5,1.65),46),
(70,77,(3.8,-6,3.4),(3.4,-5.6,3.2),(.3,.1,1.35),43),
(77,84,(-3,-4.5,2.7),(-2.8,-4.2,2.65),(.1,-.25,1.75),49),
(84,88,(3,-6,3.5),(2.7,-5.7,3.3),(0,1.3,1.45),40),
(88,92,(4,-8,4),(4.7,-9,4.6),(-.3,.7,1.4),38)]
for a,b,p,q,target,lens in shots:
 for f,loc in [(int(a*24)+1,p),(int(b*24),q)]:
  cam.location=loc;cam.rotation_euler=(Vector(target)-Vector(loc)).to_track_quat('-Z','Y').to_euler();cam.data.lens=lens;key(cam,f);cam.data.keyframe_insert('lens',frame=f)
 s.timeline_markers.new(f'SHOT {a:02d}–{b:02d}',frame=a*24+1)
for o in bpy.data.objects:
 if o.animation_data and o.animation_data.action:
  for fc in o.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
if cam.data.animation_data:
 for fc in cam.data.animation_data.action.fcurves:
  for k in fc.keyframe_points:k.interpolation='LINEAR'
s.frame_set(97);s.render.image_settings.file_format='JPEG';s.render.image_settings.quality=95;s.render.filepath=str(P/'QA/initial.jpg')
bpy.ops.wm.save_as_mainfile(filepath=str(P/'BLENDER/CASE_002_MASTER.blend'))
(P/'QA/shots.json').write_text(json.dumps(shots,indent=2))
bpy.ops.render.render(write_still=True)
