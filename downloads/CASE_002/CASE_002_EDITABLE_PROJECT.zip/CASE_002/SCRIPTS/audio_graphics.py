from pathlib import Path
import numpy as np,subprocess
from scipy.io.wavfile import write
from scipy.signal import butter,sosfilt
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1];R=48000;D=100;rng=np.random.default_rng(202)
t=np.arange(R*D,dtype=np.float64)/R
noise=rng.normal(size=len(t))
def filt(x,h,kind='lowpass'):return sosfilt(butter(2,h,fs=R,btype=kind,output='sos'),x)
rain=filt(noise,3500)*.014+filt(noise,500)*.025
wind=filt(noise,100)*.11*(.65+.35*np.sin(t*.21)**2)
drone=(np.sin(t*2*np.pi*55)+.35*np.sin(t*2*np.pi*82.6))*.018*(.6+.4*np.sin(t*.11)**2)
left=rain+wind+drone;right=np.roll(rain,173)+wind*.98+drone
out=np.column_stack([left,right])
def add(at,w,gain=1,pan=0):
 i=round(at*R);n=min(len(w),len(out)-i)
 if n>0:out[i:i+n,0]+=w[:n]*gain*(1-pan*.6);out[i:i+n,1]+=w[:n]*gain*(1+pan*.6)
def step(at,pan=0):
 q=np.arange(round(.22*R))/R;w=np.sin(2*np.pi*(95*q+20*q*q))*np.exp(-q*28)+filt(rng.normal(size=len(q)),2000)*np.exp(-q*45)*.5;add(at,w,.12,pan)
for start,end,pan in [(1.2,5.5,-.3),(8.2,11.5,0),(26,30,0),(36,39,0),(70.4,73,.4),(85.3,91,-.4)]:
 for i in range(270):
  at=(.25+i*.5)/1.35
  if start<=at<end:step(at,pan+(-.15 if i%2 else .15))
def bell(at,freq,gain,dur=3,reverse=False):
 q=np.arange(round(dur*R))/R;w=(np.sin(2*np.pi*freq*q)+.32*np.sin(2*np.pi*freq*2.71*q))*.5*np.exp(-q*2.3)
 if reverse:w=w[::-1]
 add(at,w,gain)
for a,f in [(5.5,440),(19,550),(31,880),(32,660),(34,440),(57,220),(70,110),(84,55)]:bell(a,f,.11,4)
for a in [28,54,67,81]:bell(a,277,.07,3,True)
# Mirror contact, cracks, then a short silence for the empty mirror.
for a in [30.6,31.1,34.5,85.2,86.3]:
 q=np.arange(round(.12*R))/R;add(a,(rng.normal(size=len(q))*.35+np.sin(q*2*np.pi*1400)) *np.exp(-q*55),.13)
out[round(57*R):round(58.1*R)]*=.12
for a in [70,84]:
 q=np.arange(R*2)/R;w=(np.sin(2*np.pi*(45*q-5*q*q))+.3*filt(rng.normal(size=len(q)),600))*np.exp(-q*4);add(a,w,.38)
out[92*R:]*=.2
q=np.arange(round(.35*R))/R;add(92.3,(np.sin(2*np.pi*80*q)+rng.normal(size=len(q))*.3)*np.exp(-q*20),.4)
out*=np.minimum(1,t/.08)[:,None]*np.minimum(1,(100-t)/.8)[:,None]
out=np.clip(out,-.9,.9);write(P/'AUDIO/CASE_002_SOUND_DESIGN.wav',R,(out*32767).astype(np.int16))
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';mono='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
def makecard():
 im=Image.new('RGB',(1080,1920),'#090C13');d=ImageDraw.Draw(im)
 for y in range(0,1920,6):d.line((0,y,1080,y),fill='#0B1018')
 d.rectangle((100,330,980,1510),outline='#344650',width=2);d.line((100,330,980,330),fill='#FF8928',width=7)
 def txt(t,y,size,col='#F6F0DC',b=False):d.text((540,y),t,font=ImageFont.truetype(bold if b else font,size),anchor='mt',fill=col)
 txt('THE UNHAPPENED',450,55,b=True);txt('BUREAU',520,55,b=True);txt('RECOVERED EVIDENCE',690,25,'#FF8928');txt('CASE 002',775,105,b=True)
 d.rectangle((205,955,875,1035),outline='#FF8928',width=3);txt('STATUS: UNRESOLVED',975,37,'#FF8928',True)
 txt('EVERY IMPOSSIBILITY',1215,34);txt('LEAVES EVIDENCE.',1267,34);txt('YOUR REFLECTION STAYED BEHIND',1440,23,'#7F97A1')
 im.save(P/'GRAPHICS/ENDCARD.png');im.save(P/'GRAPHICS/ENDCARD.jpg',quality=96)
makecard()
# Screen-space atmosphere loop: fine rain and foreground rain, different speeds.
w,h=540,960;drops=[]
for i in range(110):drops.append((rng.uniform(0,w),rng.uniform(0,h),rng.uniform(240,660),rng.uniform(5,16),int(rng.uniform(20,90))))
proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r','24','-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',str(P/'GRAPHICS/RAIN_LOOP.mp4')],stdin=subprocess.PIPE)
for frame in range(144):
 im=Image.new('RGB',(w,h));d=ImageDraw.Draw(im);tt=frame/24
 for x,y,speed,length,g in drops:
  yy=(y+tt*speed)%h;xx=(x+tt*speed*.13)%w;d.line((xx,yy,xx+length*.13,yy+length),fill=(int(g*.65),int(g*.85),g),width=1)
 proc.stdin.write(im.tobytes())
proc.stdin.close();assert proc.wait()==0
print('Original sound design, rain loop, and end card complete.')
