from pathlib import Path
import subprocess,sys,time
P=Path(__file__).resolve().parents[1]
while 'Blender quit' not in (P/'QA/render.log').read_text():time.sleep(3)
for name in ['assemble_episode.py','validate_episode.py','package_episode.py']:
 subprocess.run([sys.executable,str(P/'SCRIPTS'/name)],check=True)
print('FINISHED: episode, thumbnail, validation, editable project.',flush=True)
