from pathlib import Path
import subprocess,json,sys
from PIL import Image,ImageDraw,ImageFont,ImageEnhance
P=Path(__file__).resolve().parents[1]
preview='--preview' in sys.argv
missing=[f for f in range(1,193 if preview else 2209) if not (P/f'FRAMES/{f:04d}.jpg').exists()]
if missing:raise SystemExit(f'Render incomplete: {len(missing)} frames remain')
for f in range(2209,2401):
 path=P/f'FRAMES/{f:04d}.jpg'
 if not path.exists():path.symlink_to('../GRAPHICS/ENDCARD.jpg')
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';mono='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
filters=["[0:v]format=gbrp,split[clean][soft]","[soft]scale=270:480,gblur=sigma=4,scale=1080:1920[blur]","[clean][blur]blend=all_mode=screen:all_opacity=0.08[glow]","[1:v]scale=1080:1920,format=gbrp[rain]","[glow][rain]blend=all_mode=screen:all_opacity=0.45:shortest=1:enable='lt(t,92)'[wet]"]
finish=["format=yuv444p","eq=brightness=-0.025:contrast=1.08:saturation=1.07","vignette=PI/7"]
def title(txt,y,size,start,end,color='0xF6F0DC'):
 finish.append(f"drawtext=fontfile={font}:text='{txt}':fontsize={size}:fontcolor={color}:x=(w-tw)/2:y={y}:shadowcolor=black:shadowx=2:shadowy=3:enable='between(t,{start},{end})'")
title('IT STAYED.',220,70,2,6.8)
title('IT WAS NOT COPYING HIM.',220,43,19.5,22.5)
title('DO NOT TURN AROUND.',220,45,40,44.5,'0xFFB35F')
title('THE MIRROR WAS EMPTY.',220,45,58.5,62.5)
title('WHICH ONE WALKED AWAY?',220,41,88,91.8)
finish.append(f"drawtext=fontfile={mono}:text='U/B   |   CASE 002':fontsize=20:fontcolor=0xF6F0DC@0.6:x=75:y=105:enable='lt(t,92)'")
finish.append("drawbox=x=0:y=0:w=iw:h=ih:color=0xFFE5B0@0.95:t=fill:enable='between(t,83.8,84.125)'")
finish.append('fade=t=out:st=99.3:d=0.7')
filters.append('[wet]'+','.join(finish)+'[picture]')
filters.append('[2:a]loudnorm=I=-19:TP=-3:LRA=9,alimiter=limit=0.55:level=false:attack=5:release=80:latency=true[audio]')
cmd=['ffmpeg','-y','-hide_banner','-loglevel','warning','-threads','4','-framerate','24','-i',str(P/'FRAMES/%04d.jpg'),'-stream_loop','-1','-i',str(P/'GRAPHICS/RAIN_LOOP.mp4'),'-i',str(P/'AUDIO/CASE_002_SOUND_DESIGN.wav'),'-filter_complex_threads','3','-filter_complex',';'.join(filters),'-map','[picture]','-map','[audio]','-frames:v',str(192 if preview else 2400),'-t',str(8 if preview else 100),'-c:v','libx264','-threads','4','-preset','medium','-crf','19','-maxrate','5500k','-bufsize','11000k','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',str(P/('QA/PREVIEW_8s.mp4' if preview else 'FINAL/CASE_002_FINAL.mp4'))]
subprocess.run(cmd,check=True)
if preview:sys.exit(0)
# Original thumbnail uses the hook with the two independently posed characters.
subprocess.run(['ffmpeg','-v','error','-y','-ss','4','-i',str(P/'FINAL/CASE_002_FINAL.mp4'),'-frames:v','1',str(P/'QA/thumbnail_base.png')],check=True)
im=Image.open(P/'QA/thumbnail_base.png').convert('RGB');d=ImageDraw.Draw(im)
d.rectangle((65,180,1015,360),fill='#090C13')
for text,y,size,col in [('YOUR REFLECTION',200,66,'#F6F0DC'),('STAYED BEHIND.',280,67,'#FF8928')]:d.text((540,y),text,font=ImageFont.truetype(font,size),anchor='mt',fill=col)
d.rectangle((70,1590,440,1670),fill='#090C13');d.text((95,1605),'CASE 002',font=ImageFont.truetype(mono,44),fill='#F6F0DC');im.save(P/'FINAL/CASE_002_THUMBNAIL.png')
print('Final MP4 and thumbnail exported.')
