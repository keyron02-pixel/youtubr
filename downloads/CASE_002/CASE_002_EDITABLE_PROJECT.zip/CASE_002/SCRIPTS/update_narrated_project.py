import bpy
from pathlib import Path
P=Path(__file__).resolve().parents[1];s=bpy.data.scenes['02 • EDIT / TITLES / SOUND'];seq=s.sequence_editor.sequences
for strip in seq:
 if strip.type=='SOUND':strip.mute=True
voice=seq.new_sound('Narration stem (muted; included in final mix)',str(P/'AUDIO/CASE_002_NARRATION_TIMED.wav'),5,1);voice.mute=True
seq.new_sound('FINAL MIX • narration and ducked background',str(P/'AUDIO/CASE_002_NARRATED_MIX.wav'),6,1)
s.render.filepath='//../FINAL/CASE_002_NARRATED_EDIT_EXPORT.mp4'
bpy.ops.file.make_paths_relative();bpy.ops.wm.save_as_mainfile(filepath=str(P/'BLENDER/CASE_002_MASTER.blend'))
print('Narrated edit saved.')
