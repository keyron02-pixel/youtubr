from pathlib import Path
import subprocess,json,re,numpy as np
from PIL import Image,ImageDraw,ImageStat
P=Path(__file__).resolve().parents[1];video=P/'FINAL/CASE_002_FINAL.mp4'
r=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]));v=next(s for s in r['streams'] if s['codec_type']=='video');a=next(s for s in r['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1080,1920,'24/1',2400)
assert v['codec_name']=='h264' and a['codec_name']=='aac' and a['channels']==2
assert abs(float(r['format']['duration'])-100)<.05
subprocess.run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'],check=True)
r2=subprocess.run(['ffmpeg','-hide_banner','-i',str(video),'-vn','-af','loudnorm=I=-19:TP=-3:LRA=9:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
measurement=json.loads(re.search(r'\{\s*"input_i"[\s\S]*?\}',r2.stderr).group());assert float(measurement['input_tp'])<0
frames=[1,97,361,481,601,745,985,1105,1393,1657,1729,1849,2017,2065,2185,2257]
im=Image.new('RGB',(864,1696),'#090C13');d=ImageDraw.Draw(im)
for i,n in enumerate(frames):
 with Image.open(P/f'FRAMES/{n:04d}.jpg') as a:
  assert a.size==(1080,1920) and sum(ImageStat.Stat(a).stddev)>10
  a.thumbnail((216,384));x=i%4*216;y=i//4*424;im.paste(a,(x,y));d.text((x+8,y+390),f'{(n-1)/24:.2f}s',fill='white')
im.save(P/'QA/FINAL_CONTACT_SHEET.jpg')
report={'duration_seconds':100,'resolution':[1080,1920],'fps':24,'frames':2400,'codec':'H.264 / AAC stereo','native_render_resolution':[1080,1920],'decode':'passed','image_checks':'passed','audio_integrated_lufs':float(measurement['input_i']),'audio_true_peak_dbtp':float(measurement['input_tp']),'narration':'Not included; timed optional script supplied','rendering':'Stylized Workbench, custom studio light, contact shadows, composited rain/bloom','animation_checks':json.loads((P/'QA/animation_checks.json').read_text()),'limitations':['Independent duplicate simulates the mirror; no physical mirror rendering','Simple articulated object rig; no motion capture','Screen-space rain; no volumetric fog','YouTube upload not performed']}
(P/'QA/validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
