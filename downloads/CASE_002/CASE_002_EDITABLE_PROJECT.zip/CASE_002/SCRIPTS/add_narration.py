from pathlib import Path
import subprocess,json,numpy as np
from scipy.io.wavfile import read,write
P=Path(__file__).resolve().parents[1];A=P/'AUDIO';R=48000
# Boundaries checked against speech recognition and silence detection.
# Split prediction failure and reveal sentences to coincide with the visual events.
cues=[(1.45,5.78,1),(5.85,12.85,13),(12.88,21.84,25),(21.84,27.7,40),(27.75,29.84,53),(29.84,34.48,56),(34.48,42.02,71),(42.04,47.01,85),(47.02,52.57,93)]
voice=np.zeros(100*R,dtype=np.float32);details=[]
for i,(a,b,dest) in enumerate(cues):
 path=A/f'narration_clip_{i+1:02d}.wav'
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'UPLOADED_NARRATION.mp3'),'-af',f'atrim=start={a}:end={b},asetpts=PTS-STARTPTS,atempo=1.0,highpass=f=70,afade=t=in:d=0.015,areverse,afade=t=in:d=0.025,areverse','-ar',str(R),'-ac','1','-c:a','pcm_f32le',str(path)],check=True)
 sr,w=read(path);j=round(dest*R);voice[j:j+len(w)]+=w
 details.append({'source_start':a,'source_end':b,'video_start':dest,'video_end':dest+len(w)/R,'playback_rate':1.0})
write(A/'NARRATION_TIMED_RAW.wav',R,voice)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'NARRATION_TIMED_RAW.wav'),'-af','loudnorm=I=-18:TP=-2:LRA=9','-ar',str(R),'-ac','2','-c:a','pcm_s16le',str(A/'CASE_002_NARRATION_TIMED.wav')],check=True)
# Use original uploaded soundtrack from the validated MP4, with narration-driven ducking.
fc='[1:a]asplit=2[sc][voice];[0:a][sc]sidechaincompress=threshold=0.025:ratio=6:attack=25:release=400[bed];[bed][voice]amix=inputs=2:duration=longest:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=9,afade=t=out:st=99.2:d=0.8,alimiter=limit=0.56:level=false:attack=5:release=80:latency=true[mix]'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'FINAL/CASE_002_FINAL.mp4'),'-i',str(A/'CASE_002_NARRATION_TIMED.wav'),'-filter_complex',fc,'-map','[mix]','-t','100','-ar',str(R),'-ac','2','-c:a','pcm_s16le',str(A/'CASE_002_NARRATED_MIX.wav')],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'FINAL/CASE_002_FINAL.mp4'),'-i',str(A/'CASE_002_NARRATED_MIX.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','100','-movflags','+faststart',str(P/'FINAL/CASE_002_NARRATED.mp4')],check=True)
(P/'QA/narration_alignment.json').write_text(json.dumps({'source':'User-uploaded content (1).mp3','duration':52.610612,'alignment':'Local speech recognition plus silence boundaries; original narration preserved','cues':details,'mix':'Background ducking under voice, -16 LUFS normalization followed by conservative peak limiting for AAC','voice_generation':'User-supplied audio; no generation service invoked in this task'},indent=2))
print('Narrated MP4 and editable audio stems exported.')
