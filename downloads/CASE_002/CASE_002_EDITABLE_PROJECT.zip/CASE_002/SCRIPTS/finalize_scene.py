import bpy,math
from pathlib import Path
P=Path(__file__).resolve().parents[1];s=bpy.context.scene;s.display.shading.show_shadows=False
m=bpy.data.materials.new('Soft contact');m.diffuse_color=(.022,.04,.051,1)
for foot in [o for o in bpy.data.objects if '/ FOOT ' in o.name and o.type=='EMPTY']:
 me=bpy.data.meshes.new(foot.name+' contact');me.from_pydata([(math.cos(j*math.tau/24)*.16,math.sin(j*math.tau/24)*.24-.065,0) for j in range(24)],[],[list(range(24))]);me.update();o=bpy.data.objects.new(foot.name+' contact',me);s.collection.objects.link(o);o.parent=foot;o.data.materials.append(m)
 for f in range(1,2209,3):
  s.frame_set(f);o.location.z=.026-foot.location.z;o.keyframe_insert('location',frame=f)
mouth=bpy.data.objects.get('WITNESS mouth')
if mouth and mouth.animation_data:
 for fc in mouth.animation_data.action.fcurves:
  if fc.data_path=='scale' and fc.array_index==0:
   for k in fc.keyframe_points:
    if k.co.x>=1681:k.co.y=.001
s.frame_set(97);bpy.ops.wm.save_as_mainfile(filepath=str(P/'BLENDER/CASE_002_MASTER.blend'))
