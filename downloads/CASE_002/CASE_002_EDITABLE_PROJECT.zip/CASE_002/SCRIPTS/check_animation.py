import bpy,json
from pathlib import Path
P=Path(__file__).resolve().parents[1];s=bpy.data.scenes['01 • CASE 002 ANIMATION'];a=bpy.data.objects['WITNESS / ROOT'];b=bpy.data.objects['REFLECTION / ROOT']
s.frame_set(1);p1=a.location.copy();r1=b.location.copy();s.frame_set(133);p2=a.location.copy();r2=b.location.copy();assert (p2-p1).length>1 and (r2-r1).length<.001
s.frame_set(1393);assert max(b.scale)<.001
s.frame_set(1729);assert min(b.scale)>.99 and b.location.y<1
s.frame_set(2065);assert a.location.y>2 and b.location.y<1
s.frame_set(2173);assert a.location.y>2 and b.location.y<-2
counts={}
for name in ['WITNESS / ROOT','WITNESS / HEAD','WITNESS eye socket','WITNESS brow','REFLECTION / ROOT']:
 o=bpy.data.objects[name];counts[name]=sum(len(fc.keyframe_points) for fc in o.animation_data.action.fcurves)
report={'opening_independent_reflection':True,'empty_mirror_at_58s':True,'duplicate_outside_at_72s':True,'witness_inside_after_exchange':True,'duplicate_walks_away':True,'animated_control_keyframes':counts,'method':'Editable articulated object hierarchy with baked interpolated keys; independent reflection actor, no physical mirror simulation.'}
(P/'QA/animation_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
