import bpy
from pathlib import Path
P=Path(__file__).resolve().parents[1];source=bpy.context.scene
# Store final audio separately for a lightweight, self-contained editing timeline.
edit=bpy.data.scenes.new('02 • EDIT / TITLES / SOUND');edit.frame_start=1;edit.frame_end=2400;edit.render.fps=24;edit.render.resolution_x=1080;edit.render.resolution_y=1920;edit.render.resolution_percentage=100
seq=edit.sequence_editor_create().sequences
v=seq.new_scene('CASE 002 animated scene',source,1,1);v.frame_final_duration=2208
end=seq.new_image('Unresolved case file',str(P/'GRAPHICS/ENDCARD.png'),2,2209);end.frame_final_duration=192
seq.new_sound('Original rain, foley and score',str(P/'AUDIO/CASE_002_SOUND_DESIGN.wav'),4,1)
for name,body,start,end in [('Hook','IT STAYED.',49,164),('Test','IT WAS NOT COPYING HIM.',469,541),('Warning','DO NOT TURN AROUND.',961,1069),('Empty mirror','THE MIRROR WAS EMPTY.',1405,1501),('Question','WHICH ONE WALKED AWAY?',2113,2205)]:
 t=seq.new_effect(name,'TEXT',3,start,frame_end=end);t.text=body;t.font_size=45 if name!='Hook' else 70;t.color=(.965,.94,.86,1);t.location=(.5,.86);t.use_shadow=True;t.shadow_color=(.015,.025,.04,1)
edit.render.image_settings.file_format='FFMPEG';edit.render.ffmpeg.format='MPEG4';edit.render.ffmpeg.codec='H264';edit.render.ffmpeg.audio_codec='AAC';edit.render.filepath='//../FINAL/CASE_002_EDIT_EXPORT.mp4'
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA'
source.frame_set(97);bpy.ops.file.make_paths_relative();bpy.ops.wm.save_as_mainfile(filepath=str(P/'BLENDER/CASE_002_MASTER.blend'))
print('Editable scene and assembly saved.')
