import bpy,time
from pathlib import Path
P=Path(__file__).resolve().parents[1];s=bpy.context.scene;s.frame_set(1)
# Join static geometry by parent. Animated control objects and meshes remain separate.
groups={}
for o in list(bpy.data.objects):
 if o.type in {'MESH','CURVE','FONT'} and not o.animation_data:
  groups.setdefault(o.parent,[]).append(o)
for parent,objects in groups.items():
 if len(objects)<2:continue
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0]
 bpy.ops.object.convert(target='MESH');bpy.ops.object.join();bpy.context.object.name='STATIC SET' if parent is None else parent.name+' / sculpted detail'
s.render.filepath=str(P/'QA/optimized.jpg');s.frame_set(97)
bpy.context.preferences.studio_lights.load(str(P/'SCRIPTS/case02.sl'),'STUDIO');s.display.shading.studio_light='case02.sl'
bpy.ops.wm.save_as_mainfile(filepath=str(P/'BLENDER/CASE_002_MASTER.blend'))
for f in [97,98,99]:s.frame_set(f);bpy.ops.render.render(write_still=True)
print('Objects after joining:',len(bpy.data.objects))
