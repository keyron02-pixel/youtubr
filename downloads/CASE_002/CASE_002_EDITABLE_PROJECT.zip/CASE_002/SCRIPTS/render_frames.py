import bpy,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1];s=bpy.context.scene
bpy.context.preferences.studio_lights.load(str(P/'SCRIPTS/case02.sl'),'STUDIO');s.display.shading.studio_light='case02.sl';s.render.engine='BLENDER_WORKBENCH';s.display.render_aa='FXAA';s.render.resolution_percentage=100;s.render.image_settings.file_format='JPEG';s.render.image_settings.quality=95
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if args and args[0]=='review':frames=[1,97,193,289,361,481,601,745,841,985,1105,1249,1393,1513,1657,1729,1849,1969,2017,2065,2113,2185];folder=P/'QA/REVIEW';folder.mkdir(exist_ok=True)
else:
 start,end=map(int,args) if args else (1,2208);frames=range(start,end+1);folder=P/'FRAMES'
for f in frames:
 path=folder/f'{f:04d}.jpg'
 if path.exists():continue
 s.frame_set(f);s.render.filepath=str(path);bpy.ops.render.render(write_still=True)
