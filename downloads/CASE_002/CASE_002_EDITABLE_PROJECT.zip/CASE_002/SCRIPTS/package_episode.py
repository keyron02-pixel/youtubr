from pathlib import Path
import zipfile,hashlib,json
P=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(P/'FINAL/CASE_002_EDITABLE_PROJECT.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in ['BLENDER','SCRIPTS','AUDIO','GRAPHICS','QA']:
  for f in (P/folder).rglob('*'):
   if not f.is_file() or f.suffix in ['.blend1','.log']:continue
   if folder=='QA' and f.name not in ['validation.json','animation_checks.json','shots.json','FINAL_CONTACT_SHEET.jpg','narrated_validation.json','narration_alignment.json']:continue
   if f.name in ['ENDCARD.jpg','NARRATION_TIMED_RAW.wav','narration_alignment.wav'] or f.name.startswith('narration_clip_'):continue
   z.write(f,Path('CASE_002')/f.relative_to(P))
 z.write(P/'README.txt','CASE_002/README.txt')
files=[P/'FINAL'/n for n in ['CASE_002_FINAL.mp4','CASE_002_NARRATED.mp4','CASE_002_THUMBNAIL.png','CASE_002_EDITABLE_PROJECT.zip']]
assert all(f.exists() and f.stat().st_size>1000 for f in files)
assert all(f.stat().st_size<100*1024*1024 for f in files)
(P/'FINAL/SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in files))
print('Packaged files:',{f.name:f.stat().st_size for f in files})
