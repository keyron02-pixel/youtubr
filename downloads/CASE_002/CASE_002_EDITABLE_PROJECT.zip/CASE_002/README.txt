CURRENT VERSION: CASE_002_NARRATED.mp4 includes the supplied voice-over,
matched to the scenes. The original sound-design-only cut is preserved.
See QA/narrated_validation.json for the narrated export checks.

THE UNHAPPENED BUREAU — CASE 002
YOUR REFLECTION STAYED BEHIND

FINAL DELIVERABLES
CASE_002_NARRATED.mp4: current narrated cut, 100 seconds, 1080x1920, 24 fps.
CASE_002_FINAL.mp4: preserved original cut without narration.
CASE_002_THUMBNAIL.png: original vertical cover.
CASE_002_EDITABLE_PROJECT.zip: models, articulated controls, baked animation,
editable titles and sound, original audio, rain layer, automation and QA.

THE STORY
He walks away from a station mirror, but his reflection stays behind.
He tests it. It beckons him closer. Contact with the glass produces ripples.
A warning appears: DO NOT TURN AROUND. He looks back at an empty street.
The mirror is now empty. The reflection appears outside. After an exchange,
the witness is trapped in the mirror while the other version walks away.

WHAT CHANGED FROM CASE 001
Elbows, knees, articulated fingers, eye direction, blinking, brows, breathing,
head turns and a gasp expression. Footsteps match the gait cycle. The compact
station has layered architecture, beveled paving, flat puddles, reflected-light
streaks, a clock, pipes, benches, and a clearly framed mirror. A consistent shot
layout stages the hand test, warning, disappearance, meeting and exchange.
Custom warm/cool studio lighting, moving rain, subtle bloom, grading and
vignette are added to the final presentation. No paid assets or APIs were used.

EDITABLE PROJECT
Open BLENDER/CASE_002_MASTER.blend in Blender 4.3 or later.
Scene 01 contains the animation. Scene 02 contains editable scene strips,
titles, end card and original audio. Keep the relative folder layout intact.
The exact final rain/bloom/grading and sound normalization are reproduced by
SCRIPTS/assemble_episode.py. The Blender edit is the editable base assembly.
The custom studio-light file is SCRIPTS/case02.sl; render_frames.py loads it.
All original scene-building code is supplied for changing the set or rig.

STYLE AND PRACTICAL LIMITATIONS
This is stylized 3D with an object-based control rig, not motion capture.
The mirror uses a separately animated duplicate in a framed stage; it is not
a physically traced reflection. Wet reflections are stylized graphic geometry,
and rain is a composited screen-space layer. Workbench studio rendering,
contact-shadow geometry and cavity shading keep native vertical rendering
practical on the CPU. There is no ray-traced reflection or volumetric fog.

AUDIO
Original procedural rain, wind, tonal score, footsteps, glass taps, rising
mirror tones, an exchange impact and archival stamp. The user supplied Episode 2 narration as content (1).mp3. The current cut
includes that recording, aligned to the scenes, with the background lowered
during speech. No voice-generation service was invoked by the agent.
The original recording and separate timed voice and final mix are included.

REPRODUCTION (OPTIONAL; FINISHED MP4 IS READY TO USE)
Python dependencies: NumPy, SciPy, Pillow. Blender 4.3.2 and FFmpeg.
Scripts resolve paths relative to this project. Run build_episode.py in
Blender, followed by optimize_scene.py and finalize_scene.py, then render_frames.py.
audio_graphics.py creates the original soundtrack, end card and rain loop.
assemble_episode.py encodes the video and creates the thumbnail.
project_edit.py creates the editable Blender assembly. QA scripts validate
story states, format, frame counts, decoding, image samples and audio peaks.
Original high-resolution intermediate JPEG frames are retained in the cloud
workspace but omitted from the compact editable-project ZIP.

VOICE EDITING
In Scene 02, the final narrated mix is active. Original background and voice
stems remain available as muted strips. Mute the final mix before enabling
individual stems. SCRIPTS/add_narration.py recreates the alignment and mix.
