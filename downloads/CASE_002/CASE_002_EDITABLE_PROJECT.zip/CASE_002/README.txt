THE UNHAPPENED BUREAU — CASE 002
YOUR REFLECTION STAYED BEHIND

FINAL DELIVERABLES
CASE_002_FINAL.mp4: 100 seconds, vertical 1080x1920, 24 fps, H.264/AAC.
CASE_002_THUMBNAIL.png: original vertical cover.
CASE_002_EDITABLE_PROJECT.zip: models, articulated controls, baked animation,
editable titles and sound, original audio, rain layer, automation and QA.

THE STORY
He walks away from a station mirror, but his reflection stays behind.
He tests it. It beckons him closer. Contact with the glass produces ripples.
A warning appears: DO NOT TURN AROUND. He looks back at an empty street.
The mirror is now empty. The reflection appears outside. After an exchange,
the witness is trapped in the mirror while the other version walks away.

WHAT CHANGED FROM CASE 001
Elbows, knees, articulated fingers, eye direction, blinking, brows, breathing,
head turns and a gasp expression. Footsteps match the gait cycle. The compact
station has layered architecture, beveled paving, flat puddles, reflected-light
streaks, a clock, pipes, benches, and a clearly framed mirror. A consistent shot
layout stages the hand test, warning, disappearance, meeting and exchange.
Custom warm/cool studio lighting, moving rain, subtle bloom, grading and
vignette are added to the final presentation. No paid assets or APIs were used.

EDITABLE PROJECT
Open BLENDER/CASE_002_MASTER.blend in Blender 4.3 or later.
Scene 01 contains the animation. Scene 02 contains editable scene strips,
titles, end card and original audio. Keep the relative folder layout intact.
The exact final rain/bloom/grading and sound normalization are reproduced by
SCRIPTS/assemble_episode.py. The Blender edit is the editable base assembly.
The custom studio-light file is SCRIPTS/case02.sl; render_frames.py loads it.
All original scene-building code is supplied for changing the set or rig.

STYLE AND PRACTICAL LIMITATIONS
This is stylized 3D with an object-based control rig, not motion capture.
The mirror uses a separately animated duplicate in a framed stage; it is not
a physically traced reflection. Wet reflections are stylized graphic geometry,
and rain is a composited screen-space layer. Workbench studio rendering,
contact-shadow geometry and cavity shading keep native vertical rendering
practical on the CPU. There is no ray-traced reflection or volumetric fog.

AUDIO
Original procedural rain, wind, tonal score, footsteps, glass taps, rising
mirror tones, an exchange impact and archival stamp. No narration is included:
ElevenLabs tools were not available in this session. An optional timed script
is included in AUDIO/ELEVENLABS_NARRATION_SCRIPT.txt. CASE 001 narration was
not reused because it tells a different story.

REPRODUCTION (OPTIONAL; FINISHED MP4 IS READY TO USE)
Python dependencies: NumPy, SciPy, Pillow. Blender 4.3.2 and FFmpeg.
Scripts resolve paths relative to this project. Run build_episode.py in
Blender, followed by optimize_scene.py and finalize_scene.py, then render_frames.py.
audio_graphics.py creates the original soundtrack, end card and rain loop.
assemble_episode.py encodes the video and creates the thumbnail.
project_edit.py creates the editable Blender assembly. QA scripts validate
story states, format, frame counts, decoding, image samples and audio peaks.
Original high-resolution intermediate JPEG frames are retained in the cloud
workspace but omitted from the compact editable-project ZIP.
