CURRENT VERSION: rendered and validated, but the latest request for ElevenLabs
narration remains pending. The current MP4 has original sound design only.
Timed narration copy is prepared in AUDIO/ELEVENLABS_NARRATION_SCRIPT.txt.

THE UNHAPPENED BUREAU — CASE 001
Your Shadow Moved Before You Did

DELIVERABLES
FINAL/CASE_001_FINAL.mp4 — 105 seconds, 1080x1920, 24fps, H.264/AAC.
FINAL/CASE_001_THUMBNAIL.png — original vertical cover from the rendered hook.
BLENDER/CASE_001_MASTER.blend — editable models, articulated characters,
independent shadow, cameras, keyframes, lights, and an editable video sequence.
AUDIO/CASE_001_ORIGINAL_MIX.wav — original synthesized stereo soundtrack.
QA/validation.json — technical results and production limitations.
QA/FINAL_CONTACT_SHEET.jpg — representative scene frames.

Open the .blend in Blender 4.3 or later. Scene "01 • ANIMATED STREET" holds
all 3D assets and animation. Scene "02 • FINAL EDIT" holds a scene strip,
timed title images, closing card and sound. Keep the folder structure intact;
media paths are relative. Python sources are included for further editing.
The supplied MP4 additionally has FFmpeg typography, grading, vignette,
a final fade, and loudness normalization, defined in SCRIPTS/assemble.py.

STORY / EDIT
00:00–00:08  Shadow raises its hand before the witness.
00:08–00:25  A second experiment confirms the five-second offset.
00:25–00:43  Shadow moves aside; witness follows; hanging sign falls.
00:43–01:00  Shadow points; witness does not repeat it; doorway appears.
01:00–01:20  Identical person emerges without a shadow.
01:20–01:37  Shadow detaches and transfers to the other person.
01:37–01:45  Unresolved case file.
Gesture onset keyframes: shadow 24 and 264; witness 144 and 384.
Both offsets are exactly 120 frames / 5 seconds at 24fps.

TOOLS / RIGHTS
Blender, Python (NumPy, SciPy, Pillow), and FFmpeg. Original procedural models,
animation, sound synthesis, and graphic design. No purchased assets, paid APIs,
subscriptions, downloaded recordings, or third-party music. DejaVu fonts.
No voice track; the episode follows the brief's dialogue-free direction.

STYLE AND LIMITS
Native 1080x1920 stylized 3D rendering, using Blender Workbench with FXAA.
The project retains Cycles-compatible materials and lights. The delivered
render uses studio shading, stylized wet-pavement geometry, and simple
articulated animation; it does not include ray-traced reflections or volumetric
fog. Render-engine choice was made after CPU benchmarking and discovering
that the available Blender build lacks OpenImageDenoise support.

REPRODUCIBILITY
The project is already produced; no production work is required to use the MP4.
For future edits only: render.py renders/resumes source scene frames;
sound_and_graphics.py regenerates the sound and cards; assemble.py performs
the exact final encode; validate.py inspects and fully decodes the result.
The initial construction scripts use the original workspace path; change P if
rebuilding elsewhere. The .blend and relative media work without these scripts.
Intermediate JPEG frames are retained separately in the production workspace.
