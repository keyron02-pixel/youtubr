from pathlib import Path
import numpy as np
from scipy.signal import butter,sosfilt
from scipy.io.wavfile import write
from PIL import Image,ImageDraw,ImageFont
P=Path('/workspace/THE_UNHAPPENED_BUREAU/CASE_001');R=48000;D=105;rng=np.random.default_rng(42)
t=np.arange(R*D)/R
noise=rng.normal(size=len(t)).astype(np.float32)
def filt(a,hz,kind='lowpass'):return sosfilt(butter(2,hz,fs=R,btype=kind,output='sos'),a)
amb=filt(noise,1100)*.035+filt(noise,100)*.12
amb*=.7+.3*np.sin(t*.27)**2
music=(np.sin(2*np.pi*55*t)+.35*np.sin(2*np.pi*82.41*t)+.22*np.sin(2*np.pi*110.2*t))*.017
music*=.6+.4*np.sin(t*.18)**2
music+=np.sin(2*np.pi*(164.81*t+.5*np.sin(t*.1)))*.006
out=amb+music
# Original Foley, impacts and portal tones, no external recordings.
def add(at,wave,gain=1):
 i=round(at*R);n=min(len(wave),len(out)-i)
 if n>0:out[i:i+n]+=wave[:n]*gain
def thud(at,gain=1,heavy=False):
 q=np.arange(int(R*(2 if heavy else .24)))/R
 w=np.sin(2*np.pi*(45 if heavy else 140)*q)*np.exp(-q*(4 if heavy else 24))
 w+=rng.normal(size=len(q))*np.exp(-q*(30 if heavy else 70))*.5
 add(at,w,gain)
for at in np.arange(47.2,60,.5):thud(at,.08)
for at in np.arange(60.5,68,.55):thud(at,.07)
for at in [30.1,30.5,75,75.5]:thud(at,.11)
thud(32.7,.55,True)
for at in [1,6,11,16,43,48]:
 q=np.arange(int(R*.7))/R;add(at,np.sin(2*np.pi*(880 if at<40 else 440)*q)*np.exp(-q*10),.04)
for at in [43.5,60,80,90]:
 q=np.arange(R*7)/R;env=np.sin(np.pi*q/7)**2
 add(at,env*(np.sin(2*np.pi*(80*q+4*q*q))*.04+filt(rng.normal(size=len(q)),1800)*.04))
# Prediction failure: deliberate drop in ambience.
out[int(48*R):int(50*R)]*=.22
out[int(97*R):]*=.22
thud(97.2,.4);thud(97.32,.2)
fade=np.minimum(1,np.arange(len(out))/(R*.1))*np.minimum(1,(len(out)-1-np.arange(len(out)))/(R*1.5));out*=fade
stereo=np.column_stack([out,np.roll(out,123)*.97]);stereo/=max(1,np.max(np.abs(stereo))/.86)
write(P/'AUDIO/CASE_001_ORIGINAL_MIX.wav',R,(stereo*32767).astype(np.int16))
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';mono='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
def f(n,b=False):return ImageFont.truetype(bold if b else font,n)
ink='#090C13';ivory='#F6F0DC';amber='#FF8928'
im=Image.new('RGB',(1080,1920),ink);d=ImageDraw.Draw(im)
for y in range(0,1920,6):d.line((0,y,1080,y),fill='#0C1019')
d.rectangle((96,325,984,1510),outline='#39414B',width=2);d.line((96,325,984,325),fill=amber,width=8)
def centered(txt,y,size,color=ivory,b=False):d.text((540,y),txt,font=f(size,b),anchor='mt',fill=color)
centered('THE UNHAPPENED',440,55,ivory,True);centered('BUREAU',510,55,ivory,True)
centered('RECOVERED EVIDENCE',700,27,amber);centered('CASE 001',770,108,ivory,True)
d.rectangle((205,945,875,1035),outline=amber,width=3);centered('STATUS: UNRESOLVED',966,39,amber,True)
centered('EVERY IMPOSSIBILITY',1220,34);centered('LEAVES EVIDENCE.',1272,34)
centered('YOUR SHADOW MOVED BEFORE YOU DID',1440,20,'#7C8794')
im.save(P/'QA/endcard.png')
# Mobile-safe typography overlays stored as editable raster assets + source.
for name,lines in [('hook',['IT MOVED FIRST.']),('timer',['5 SECONDS AHEAD']),('failed',['PREDICTION FAILED.']),('question',['WHO DID THE SHADOW','BELONG TO?'])]:
 im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
 for j,txt in enumerate(lines):
  y=235+j*66;d.text((541,y+3),txt,font=f(49,True),anchor='mt',fill=(0,0,0,230),stroke_width=4);d.text((540,y),txt,font=f(49,True),anchor='mt',fill=ivory)
 d.line((440,205,640,205),fill=amber,width=5);im.save(P/('QA/'+name+'.png'))
print('Original stereo soundtrack and title graphics created.')
