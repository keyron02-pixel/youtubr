from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parents[1]
missing=[f for f in range(1,2329) if not (P/f'FRAMES/{f:04d}.jpg').exists()]
if missing:raise SystemExit(f'Render incomplete: {len(missing)} frames remain')
im=Image.open(P/'QA/endcard.png');im.save(P/'QA/endcard.jpg',quality=96)
for f in range(2329,2521):
 dst=P/f'FRAMES/{f:04d}.jpg'
 if not dst.exists():dst.symlink_to('../QA/endcard.jpg')
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
mono='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
filters=["eq=contrast=1.045:saturation=1.08", "vignette=PI/6"]
def label(txt,y,size,start,end,color='0xF6F0DC'):
 filters.append(f"drawtext=fontfile={font}:text='{txt}':fontsize={size}:fontcolor={color}:x=(w-tw)/2:y={y}:shadowcolor=black:shadowx=2:shadowy=3:enable='between(t,{start},{end})'")
label('IT MOVED FIRST.',235,51,1.2,5)
label('5 SECONDS AHEAD',235,48,16,21,'0xFF8928')
label('PREDICTION FAILED.',235,48,48,52,'0xFF8928')
label('WHO DID THE SHADOW',235,46,93,96.9)
label('BELONG TO?',297,46,93,96.9)
filters.append(f"drawtext=fontfile={mono}:text='U/B   •   CASE 001':fontsize=20:fontcolor=0xF6F0DC@0.65:x=80:y=110:enable='lt(t,97)'")
filters.append('fade=t=out:st=104.3:d=0.7')
cmd=['ffmpeg','-y','-hide_banner','-loglevel','warning','-framerate','24','-i',str(P/'FRAMES/%04d.jpg'),'-i',str(P/'AUDIO/CASE_001_ORIGINAL_MIX.wav'),'-vf',','.join(filters),'-frames:v','2520','-t','105','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-af','loudnorm=I=-18:TP=-1.5:LRA=9','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',str(P/'FINAL/CASE_001_FINAL.mp4')]
subprocess.run(cmd,check=True)
# Thumbnail uses the rendered hook, when the shadow has raised its hand and the witness has not.
im=Image.open(P/'FRAMES/0048.jpg').convert('RGB');d=ImageDraw.Draw(im)
for txt,y,size,col in [('YOUR SHADOW',175,78,'#F6F0DC'),('MOVED FIRST.',270,74,'#FF8928')]:
 d.text((540,y),txt,font=ImageFont.truetype(font,size),anchor='mt',fill=col,stroke_width=3,stroke_fill='#090C13')
d.rectangle((75,1570,495,1650),fill='#090C13');d.text((100,1582),'CASE 001',font=ImageFont.truetype(mono,48),fill='#F6F0DC')
im.save(P/'FINAL/CASE_001_THUMBNAIL.png')
print('Final video and thumbnail exported.')
