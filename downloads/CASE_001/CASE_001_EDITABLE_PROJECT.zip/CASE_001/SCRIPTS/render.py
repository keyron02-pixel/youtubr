import bpy, os, sys, time
P='/workspace/THE_UNHAPPENED_BUREAU/CASE_001';s=bpy.context.scene
s.render.engine='BLENDER_WORKBENCH';s.render.resolution_percentage=100
s.display.render_aa='FXAA';s.display.shading.light='STUDIO';s.display.shading.studiolight_rotate_z=.3;s.display.shading.color_type='MATERIAL';s.display.shading.show_shadows=False;s.display.shading.show_cavity=True;s.display.shading.cavity_type='BOTH';s.display.shading.background_type='WORLD';s.display.shading.show_specular_highlight=True
s.render.image_settings.file_format='JPEG';s.render.image_settings.quality=93
# Flattened shadow has a dark matte surface; retain actual animated geometry.
for o in bpy.data.objects:
 if o.name.startswith('Evidence shadow') and o.type=='MESH':
  for p in o.data.polygons:p.use_smooth=False
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
start,end,step=map(int,args) if args else (1,2328,1)
for f in range(start,end+1,step):
 path=P+'/FRAMES/%04d.jpg'%f
 if os.path.exists(path):continue
 s.frame_set(f);s.render.filepath=path;bpy.ops.render.render(write_still=True)
