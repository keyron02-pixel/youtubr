import bpy,math
from mathutils import Vector
P='/workspace/THE_UNHAPPENED_BUREAU/CASE_001';s=bpy.context.scene;cam=s.camera
# Revise framing after contact-sheet review: show both people and the entire shadow.
cam.data.lens=36
shots=[(1033,1200,(5,-8,8),(4.7,-7,7.5),(0,2,1)),(1201,1440,(-5,-3,5),(-5,0,5),(0,5,1.2)),(1825,1920,(5,-4,7),(5,-3.5,7),(.1,3.8,.7)),(1921,2160,(5,-4,10),(5,-3.5,10),(.1,3.5,.3))]
for start,end,a,b,target in shots:
 for f,p in [(start,a),(end,b)]:
  cam.location=p;cam.rotation_euler=(Vector(target)-Vector(p)).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f)
portal=bpy.data.objects['Doorway master']
for o in portal.children:o.location-=Vector((1.1,8,0))
portal.location=(1.1,8,0)
# Stylized shadow should read as a matte surface, without specular modelling.
for o in bpy.data.objects:
 if o.name.startswith('Evidence shadow') and o.type=='MESH':
  for m in o.data.materials:m.diffuse_color=(.002,.003,.006,1)
# Phone prop, deliberately visible only during the experiment.
bpy.ops.mesh.primitive_cube_add(size=1);o=bpy.context.object;o.name='Witness phone';o.dimensions=(.14,.045,.24);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
o.parent=bpy.data.objects['Witness arm pivot'];o.location=(-.08,-.08,-.55)
m=bpy.data.materials.new('Phone screen');m.diffuse_color=(.22,.6,.75,1);o.data.materials.append(m)
for f,v in [(1,0),(370,0),(376,1),(470,1),(476,0)]:o.scale=(v,v,v);o.keyframe_insert('scale',frame=f)
s.render.engine='BLENDER_WORKBENCH';s.render.resolution_percentage=100;s.display.render_aa='FXAA';s.display.shading.light='STUDIO';s.display.shading.color_type='MATERIAL';s.display.shading.show_shadows=False;s.display.shading.show_cavity=True;s.display.shading.cavity_type='BOTH';s.display.shading.background_type='WORLD'
for o in bpy.data.objects:
 if o.animation_data and o.animation_data.action:
  for fc in o.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
s.frame_set(45);bpy.ops.wm.save_as_mainfile(filepath=P+'/BLENDER/CASE_001_MASTER.blend')
