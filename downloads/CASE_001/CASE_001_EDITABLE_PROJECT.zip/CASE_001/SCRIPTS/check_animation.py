import bpy,json
from pathlib import Path
P=Path('/workspace/THE_UNHAPPENED_BUREAU/CASE_001');s=bpy.data.scenes['01 • ANIMATED STREET']
def curve(n):
 o=bpy.data.objects[n]
 return {int(k.co[0]):round(k.co[1],4) for f in o.animation_data.action.fcurves if f.data_path=='rotation_euler' and f.array_index==1 for k in f.keyframe_points}
a=curve('Evidence shadow arm pivot.001');b=curve('Witness arm pivot.001')
assert all(a[x]==b[x+120] for x in [24,42,74,96])
a=curve('Evidence shadow arm pivot');b=curve('Witness arm pivot')
assert all(a[x]==b[x+120] for x in [264,282,314,336])
s.frame_set(1920);shadow=bpy.data.objects['Evidence shadow'];hero=bpy.data.objects['Witness'];other=bpy.data.objects['Other']
assert (shadow.location-hero.location).length<.03
s.frame_set(2160);assert (shadow.location-other.location).length<.03
assert (shadow.location-hero.location).length>1
assert all(not o.visible_shadow for o in bpy.data.objects if o.type=='MESH' and o.name.startswith('Other') and o.name!='Other phone')
(P/'QA/animation_checks.json').write_text(json.dumps({'gesture_1_offset_frames':120,'gesture_2_offset_frames':120,'gesture_curves_match':True,'shadow_starts_at_witness':True,'shadow_ends_at_duplicate':True,'duplicate_physical_shadows_disabled':True},indent=2))
print('Animation timing and shadow attachment checks passed.')
