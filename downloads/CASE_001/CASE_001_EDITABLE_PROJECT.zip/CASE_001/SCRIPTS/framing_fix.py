import bpy
from mathutils import Vector
P='/workspace/THE_UNHAPPENED_BUREAU/CASE_001';s=bpy.context.scene;c=s.camera
for f,p in [(1033,(0,-10,11)),(1200,(0,-9,10.5))]:
 c.location=p;c.rotation_euler=(Vector((0,2,.3))-Vector(p)).to_track_quat('-Z','Y').to_euler();c.keyframe_insert('location',frame=f);c.keyframe_insert('rotation_euler',frame=f)
for fc in c.animation_data.action.fcurves:
 for k in fc.keyframe_points:k.interpolation='LINEAR'
bpy.ops.wm.save_as_mainfile(filepath=P+'/BLENDER/CASE_001_MASTER.blend')
