from pathlib import Path
import time,subprocess,sys,zipfile
P=Path(__file__).resolve().parents[1]
for log in ['final_render.log','framing_render.log']:
 while 'Blender quit' not in (P/'QA'/log).read_text():time.sleep(3)
for script in ['assemble.py','validate.py']:
 subprocess.run([sys.executable,str(P/'SCRIPTS'/script)],check=True)
# Self-contained editable project, including all relative media but excluding large caches.
with zipfile.ZipFile(P/'FINAL/CASE_001_EDITABLE_PROJECT.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for root in ['BLENDER','SCRIPTS','AUDIO','QA']:
  for f in (P/root).rglob('*'):
   if f.is_file() and f.suffix not in ['.blend1','.log'] and f.name not in ['test.png','eevee.png','workbench.png','fast.png','endcard.jpg']:
    z.write(f,Path('CASE_001')/f.relative_to(P))
 z.write(P/'README.txt','CASE_001/README.txt')
print('FINISHED: export, validation, and editable package complete.',flush=True)
