import json,subprocess
from pathlib import Path
from PIL import Image,ImageStat,ImageDraw
P=Path(__file__).resolve().parents[1];video=P/'FINAL/CASE_001_FINAL.mp4'
r=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]))
v=next(s for s in r['streams'] if s['codec_type']=='video');a=next(s for s in r['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1080,1920)
assert v['r_frame_rate']=='24/1' and int(v['nb_frames'])==2520
assert v['codec_name']=='h264' and a['codec_name']=='aac'
assert abs(float(r['format']['duration'])-105)<.05
subprocess.run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'],check=True)
frames=[48,168,288,408,625,793,1081,1177,1501,1657,1777,1921,2041,2161,2281,2401]
sheet=Image.new('RGB',(864,1696),'#090C13');d=ImageDraw.Draw(sheet)
for i,n in enumerate(frames):
 src=P/f'FRAMES/{n:04d}.jpg'
 with Image.open(src) as im:
  assert im.size==(1080,1920)
  assert sum(ImageStat.Stat(im).stddev)>10
  im.thumbnail((216,384));sheet.paste(im,(i%4*216,i//4*424));d.text((i%4*216+8,i//4*424+390),f'{(n-1)/24:.2f}s',fill='white')
sheet.save(P/'QA/FINAL_CONTACT_SHEET.jpg')
report={'duration_seconds':105,'resolution':[1080,1920],'fps':24,'video_frames':2520,'video_codec':'H.264','audio_codec':'AAC stereo','audio_hz':a['sample_rate'],'full_decode':'passed','rendered_scene_frames':2328,'endcard_frames':192,'shadow_lead_frames':120,'shadow_gesture_onsets':[24,264],'witness_gesture_onsets':[144,384],'native_render_resolution':[1080,1920],'renderer':'Blender Workbench / FXAA','audio':'Original procedural synthesis; no voice or third-party music','visual_review':'Representative frames checked; doorway and transfer cameras widened after first review','limitations':['Stylized studio lighting; no ray-traced reflections or volumetric fog','Simple articulated character animation; no facial performance capture','YouTube upload and platform processing not performed']}
(P/'QA/validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
