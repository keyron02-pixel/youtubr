import bpy, math, random, os
from mathutils import Vector
P='/workspace/THE_UNHAPPENED_BUREAU/CASE_001'
random.seed(11)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
s=bpy.context.scene
s.render.engine='CYCLES'; s.cycles.samples=8;s.cycles.use_denoising=False
s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=50
s.render.fps=24;s.frame_start=1;s.frame_end=2520
s.world.color=(.08,.08,.08)
s.render.image_settings.file_format='PNG'
s.view_settings.view_transform='AgX'
def mat(n,c,metal=0,rough=.5,emit=0):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True
 b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough
 b.inputs['Emission Color'].default_value=(*c,1);b.inputs['Emission Strength'].default_value=emit
 return m
navy=mat('Midnight enamel',(.035,.065,.105),.4);road=mat('Rain-dark asphalt',(.055,.08,.105),.45,.22);ivory=mat('Ivory canvas',(.78,.72,.55));skin=mat('Warm porcelain',(.65,.36,.22));hair=mat('Ink hair',(.018,.025,.035));orange=mat('Case amber', (1,.23,.025),.1,.3,4);window=mat('Warm windows',(.9,.42,.13),0,.5,1.4);dark=mat('Independent shadow',(.004,.006,.012),0,1);white=mat('Crosswalk ivory',(.45,.49,.48),.2,.3);blue=mat('Blue steel',(.08,.16,.23),.6);eye=mat('Eye ivory',(.92,.9,.79));puddle=mat('Wet reflections',(.1,.19,.25),.75,.08)
def cube(n,loc,scale,m,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if bevel: mod=o.modifiers.new('Soft machined edges','BEVEL');mod.width=bevel;mod.segments=2;o.modifiers.new('Normals','WEIGHTED_NORMAL')
 return o
def ball(n,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 return o
def rod(n,a,b,r,m,parent=None):
 a,b=Vector(a),Vector(b);o=ball(n,(a+b)/2,(r,r,(a-b).length/2+r),m);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();o.parent=parent;return o
def text(n,body,loc,size,m,rot=(math.pi/2,0,0)):
 c=bpy.data.curves.new(n,'FONT');c.body=body;c.align_x='CENTER';c.size=size;c.extrude=.002;o=bpy.data.objects.new(n,c);s.collection.objects.link(o);o.location=loc;o.rotation_euler=rot;o.data.materials.append(m);return o
def key(o,f,loc=None,rot=None,scale=None):
 if loc is not None:o.location=loc;o.keyframe_insert('location',frame=f)
 if rot is not None:o.rotation_euler=rot;o.keyframe_insert('rotation_euler',frame=f)
 if scale is not None:o.scale=scale;o.keyframe_insert('scale',frame=f)
# Compact reusable street set
cube('Street',(0,3,-.12),(15,30,.2),road)
for x in [-5,5]:
 cube('Curb',(x,3,.03),(1,30,.25),blue,.05)
 for y in range(-8,17,4):
  h=random.uniform(5,9);cube('Store masonry',(x+(-1 if x<0 else 1),y,h/2),(2,3.8,h),navy,.08)
  for z in [1.3,3.6,5.4]:
   for dy in [-.9,.4]:
    cube('Window',(x+(.06 if x<0 else -.06),y+dy,z),(.04,.85,1.1),window)
  cube('Awning',(x+(.38 if x<0 else -.38),y,2.25),(.9,3,.15),blue,.03)
for x in [-3,-2,-1,0,1,2,3]:cube('Crosswalk',(x,-1,.004),(.55,2.4,.015),white)
for i in range(40):
 o=ball('Puddle',(random.uniform(-4,4),random.uniform(-8,15),.006),(random.uniform(.1,.6),random.uniform(.3,1.4),.006),puddle)
for x,y in [(-4,-3),(4,2),(-4,7),(4,11)]:
 rod('Streetlight',(x,y,0),(x,y,4.8),.065,blue);rod('Lamp arm',(x,y,4.8),(x*.7,y,4.8),.065,blue);ball('Lamp',(x*.7,y,4.7),(.35,.2,.09),orange)
 for pos in [(x*.7,y,4.4)]:
  bpy.ops.object.light_add(type='AREA',location=pos);bpy.context.object.data.energy=200;bpy.context.object.data.color=(1,.45,.16);bpy.context.object.data.shape='DISK';bpy.context.object.data.size=3
text('Shop sign','NIGHT / ARCHIVE',(-4.4,3,2.8),.25,ivory,(math.pi/2,0,math.pi/2))
# Articulated character with explicit independent shadow duplicate

def character(n,shadow=False):
 root=bpy.data.objects.new(n,None);s.collection.objects.link(root)
 parts=[]
 def add(o):o.parent=root;parts.append(o);return o
 m=dark if shadow else ivory;sk=dark if shadow else skin;ha=dark if shadow else hair
 add(cube(n+' coat',(0,0,1.38),(.69,.38,.83),m,.12))
 add(ball(n+' head',(0,-.015,2.08),(.32,.27,.36),sk))
 add(ball(n+' hair',(0,.025,2.28),(.34,.28,.22),ha))
 for j in range(5):add(ball(n+' fringe',(-.25+j*.12,-.2,2.26+random.uniform(-.04,.06)),(.11,.1,.16),ha))
 if not shadow:
  for x in [-.115,.115]:
   add(ball(n+' eye',(x,-.263,2.09),(.073,.035,.085),eye));add(ball(n+' pupil',(x,-.295,2.09),(.035,.012,.048),hair))
  add(ball(n+' nose',(0,-.285,1.99),(.055,.065,.065),skin))
  add(cube(n+' pocket',(.15,-.203,1.42),(.18,.025,.22),blue,.02))
 add(cube(n+' shoulder bag',(.4,.04,1.04),(.28,.3,.4),ha,.06))
 add(rod(n+' bag strap',(-.24,-.22,1.78),(.39,-.22,1.08),.025,ha))
 arms=[];legs=[]
 for side in [-1,1]:
  pivot=bpy.data.objects.new(n+' arm pivot',None);s.collection.objects.link(pivot);pivot.parent=root;pivot.location=(side*.4,0,1.7)
  a=rod(n+' sleeve',(0,0,0),(side*.08,0,-.47),.115,m,pivot)
  hand=ball(n+' hand',(side*.08,0,-.57),(.105,.105,.13),sk);hand.parent=pivot;arms.append(pivot)
  pivot=bpy.data.objects.new(n+' leg pivot',None);s.collection.objects.link(pivot);pivot.parent=root;pivot.location=(side*.18,0,1.03)
  rod(n+' trousers',(0,0,0),(0,0,-.73),.13,ha,pivot)
  shoe=cube(n+' boot',(0,-.09,-.88),(.27,.43,.2),ha,.05);shoe.parent=pivot;legs.append(pivot)
 return root,arms,legs
hero,ha,hl=character('Witness');double,da,dl=character('Other');sh,sa,sl=character('Evidence shadow',True)
# Ground-projected controllable silhouette; ordinary cast shadows disabled
for o in bpy.data.objects:
 if o.type=='MESH' and (o.name.startswith('Witness') or o.name.startswith('Other')):o.visible_shadow=False
sh.rotation_euler=(math.pi/2,0,-.28);sh.scale=(1, .035,1.6)
# Main trajectory and movement timing
for f,p in [(1,(0,0,0)),(719,(0,0,0)),(744,(-1.4,0,0)),(1128,(-1.4,0,0)),(1440,(-.6,4,0)),(1776,(-.6,4,0)),(1830,(-.9,3.3,0)),(2328,(-.9,3.3,0))]:key(hero,f,loc=p)
for f,p in [(1,(0,0,.025)),(599,(0,0,.025)),(624,(-1.4,0,.025)),(1128,(-1.4,0,.025)),(1440,(-.6,4,.025)),(1776,(-.6,4,.025)),(1830,(-.9,3.3,.025)),(1920,(-.9,3.3,.025)),(2160,(1.1,5,.025)),(2328,(1.1,5,.025))]:key(sh,f,loc=p)
for f,p in [(1,(1.1,8,0)),(1440,(1.1,8,0)),(1632,(1.1,5,0)),(2328,(1.1,5,0))]:key(double,f,loc=p)
for f,z in [(1,0),(1439,0),(1440,1)]:key(double,f,scale=(z,z,z))
def gesture(arms,start,delay=0,side=1,angle=-2.5):
 a=arms[side]
 for f,v in [(start+delay,0),(start+delay+18,angle),(start+delay+50,angle),(start+delay+72,0)]:key(a,f,rot=(0,v,0))
gesture(sa,24);gesture(ha,144)
gesture(sa,264,side=0,angle=1.7);gesture(ha,384,side=0,angle=1.7)
gesture(sa,1032,side=1,angle=-1.6)
# Head tilts and stance motion
for arms,legs,start,end in [(ha,hl,1128,1440),(da,dl,1440,1632)]:
 for f in range(start,end+1,12):
  v=math.sin((f-start)/24*math.pi*2)*.38
  for j,o in enumerate(legs):key(o,f,rot=(v*(-1 if j else 1),0,0))
  for j,o in enumerate(arms):key(o,f,rot=(-v*.6*(-1 if j else 1),0,0))
 for o in legs+arms:key(o,end,rot=(0,0,0))
for f,v in [(1,0),(190,0),(220,-.25),(260,0),(800,.25),(860,0),(1800,0),(1870,-.25),(1920,0)]:key(hero,f,rot=(0,0,v))
for f,v in [(1632,0),(2160,0),(2240,.38),(2328,.38)]:key(double,f,rot=(0,0,v))
# Falling warning sign
sign=cube('Falling transit sign',(0,0,4.5),(1.25,.16,.75),blue,.05)
for f,p,r in [(1,(0,0,4.5),(0,0,0)),(766,(0,0,4.5),(0,0,0)),(786,(0,0,.15),(math.pi/2,.3,.2)),(800,(0,0,.12),(math.pi/2,0,.2))]:key(sign,f,loc=p,rot=r)
# Portal architecture
portal=bpy.data.objects.new('Doorway master',None);s.collection.objects.link(portal)
for loc,sc in [((-.05,8,1.8),(.13,.22,3.6)),((2.25,8,1.8),(.13,.22,3.6)),((1.1,8,3.6),(2.4,.22,.13))]:o=cube('Luminous portal jamb',loc,sc,orange,.04);o.parent=portal
for i in range(8):
 o=cube('Portal veil',(1.1,8+i*.04,1.8),(2.1,.01,3.4),mat('Veil '+str(i),(.2,.045,.008),0,.8,.3));o.parent=portal
for f,v in [(1,0),(1044,0),(1050,1),(1053,.03),(1058,1),(1061,.4),(1065,1),(2240,1),(2250,.01),(2254,1),(2260,0)]:key(portal,f,scale=(v,v,v))
# Falling amber leaves
for i in range(16):
 o=ball('Windborne leaf',(0,0,0),(.04,.1,.012),ivory)
 for f in range(1,2521,120):key(o,f,loc=(random.uniform(-4,4),random.uniform(-4,12),random.uniform(.2,5)),rot=(random.random()*3,0,random.random()*6))
# Lighting
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.12,.18,.3,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.4
for loc,power,color,size in [((1,-5,8),1600,(.6,.75,1),8),((-4,5,6),2200,(1,.42,.13),7),((1,7,3),400,(1,.2,.03),3)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.color=color;o.data.size=size;o.rotation_euler=(Vector((0,3,1))-o.location).to_track_quat('-Z','Y').to_euler()
# Shot cuts and smooth pushes
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.lens=42
shots=[(1,192,(5,-8,7),(3.6,-6.5,6),(0,-.7,.8)),(193,360,(-3,-5,3.4),(-2.4,-4.7,3),(0,-.5,1)),(361,480,(.9,-2.8,2.3),(.65,-2.5,2.25),(0,0,1.9)),(481,600,(3,-5,1.8),(2.4,-4.5,1.6),(0,-1,.5)),(601,840,(4,-7,5),(3,-6,4.7),(-.4,0,1)),(841,1032,(-3,-3,2.8),(-2.6,-2.8,2.6),(-1.4,0,1.65)),(1033,1200,(4,-5,6),(3.6,-4,5.5),(0,3,1)),(1201,1440,(-3,-1,3.1),(-3,2,3.1),(0,7,1.7)),(1441,1632,(4,1,3.5),(3.6,1.5,3.2),(1.1,6.5,1.8)),(1633,1728,(-1.6,1.5,2.4),(-1.5,1.8,2.35),(-.6,4,1.95)),(1729,1824,(2.1,2.7,2.45),(1.9,2.9,2.4),(1.1,5,1.98)),(1825,1920,(4,-1,5),(3.7,-.7,4.8),(.1,4,1)),(1921,2160,(4,-1,8),(3.6,-.5,8),(.1,3.5,.4)),(2161,2256,(2.5,1.6,3),(2.3,1.8,2.8),(1.1,5,1.7)),(2257,2328,(5,-5,7),(6,-7,8),(0,4,1)),(2329,2520,(5,-5,7),(5,-5,7),(0,4,1))]
for start,end,a,b,target in shots:
 for f,p in [(start,a),(end,b)]:key(cam,f,loc=p,rot=(Vector(target)-Vector(p)).to_track_quat('-Z','Y').to_euler())
for o in bpy.data.objects:
 if o.animation_data and o.animation_data.action:
  for fc in o.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
s.render.film_transparent=False
s.render.filepath=P+'/QA/test.png';s.frame_set(170)
bpy.ops.wm.save_as_mainfile(filepath=P+'/BLENDER/CASE_001_MASTER.blend')
bpy.ops.render.render(write_still=True)
