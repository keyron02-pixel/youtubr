import bpy
from pathlib import Path
P=Path('/workspace/THE_UNHAPPENED_BUREAU/CASE_001');s=bpy.data.scenes['02 • FINAL EDIT'];seq=s.sequence_editor.sequences
for strip in seq:
 if strip.type=='SOUND':strip.mute=True
v=seq.new_sound('Narration stem (muted; included in final mix)',str(P/'AUDIO/CASE_001_NARRATION_TIMED.wav'),4,1);v.mute=True
seq.new_sound('FINAL MIX • narration and ducked background',str(P/'AUDIO/CASE_001_NARRATED_MIX.wav'),5,1)
s.render.filepath='//../FINAL/CASE_001_NARRATED_EDIT_EXPORT.mp4'
bpy.ops.file.make_paths_relative();bpy.ops.wm.save_as_mainfile(filepath=str(P/'BLENDER/CASE_001_MASTER.blend'))
print('Narrated project updated.')
