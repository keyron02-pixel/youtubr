from pathlib import Path
import subprocess,json,numpy as np
from scipy.io.wavfile import read,write
P=Path(__file__).resolve().parents[1];A=P/'AUDIO';R=48000
# Boundaries checked against speech recognition and silence detection.
# Split prediction failure and reveal sentences to coincide with the visual events.
cues=[(0,1.85,.6),(1.95,5.5,11),(5.55,9.6,29),(9.6,11.2,43.5),(11.2,12.84,48.2),(12.84,14.5,50.2),(14.5,19.6,61),(19.6,21.5,81),(21.5,23.55,87),(23.55,25.55,91),(25.55,27.18,97.5),(27.18,28.9,100),(28.9,29.93,102.5)]
voice=np.zeros(105*R,dtype=np.float32);details=[]
for i,(a,b,dest) in enumerate(cues):
 path=A/f'narration_clip_{i+1:02d}.wav'
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'UPLOADED_NARRATION.mp3'),'-af',f'atrim=start={a}:end={b},asetpts=PTS-STARTPTS,atempo=0.92,highpass=f=70,afade=t=in:d=0.015,areverse,afade=t=in:d=0.025,areverse','-ar',str(R),'-ac','1','-c:a','pcm_f32le',str(path)],check=True)
 sr,w=read(path);j=round(dest*R);voice[j:j+len(w)]+=w
 details.append({'source_start':a,'source_end':b,'video_start':dest,'video_end':dest+len(w)/R,'playback_rate':.92})
write(A/'NARRATION_TIMED_RAW.wav',R,voice)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(A/'NARRATION_TIMED_RAW.wav'),'-af','loudnorm=I=-18:TP=-2:LRA=9','-ar',str(R),'-ac','2','-c:a','pcm_s16le',str(A/'CASE_001_NARRATION_TIMED.wav')],check=True)
# Use original uploaded soundtrack from the validated MP4, with narration-driven ducking.
fc='[1:a]asplit=2[sc][voice];[0:a][sc]sidechaincompress=threshold=0.025:ratio=6:attack=25:release=400[bed];[bed][voice]amix=inputs=2:duration=longest:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=9,afade=t=out:st=104.2:d=0.8[mix]'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'FINAL/CASE_001_FINAL.mp4'),'-i',str(A/'CASE_001_NARRATION_TIMED.wav'),'-filter_complex',fc,'-map','[mix]','-t','105','-ar',str(R),'-ac','2','-c:a','pcm_s16le',str(A/'CASE_001_NARRATED_MIX.wav')],check=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'FINAL/CASE_001_FINAL.mp4'),'-i',str(A/'CASE_001_NARRATED_MIX.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','105','-movflags','+faststart',str(P/'FINAL/CASE_001_NARRATED.mp4')],check=True)
(P/'QA/narration_alignment.json').write_text(json.dumps({'source':'User-uploaded content.mp3','duration':29.962449,'alignment':'Local speech recognition plus silence boundaries; original narration preserved','cues':details,'mix':'Background ducking under voice, -16 LUFS target, -1.5 dBTP ceiling','voice_generation':'User-supplied audio; no generation service invoked in this task'},indent=2))
print('Narrated MP4 and editable audio stems exported.')
