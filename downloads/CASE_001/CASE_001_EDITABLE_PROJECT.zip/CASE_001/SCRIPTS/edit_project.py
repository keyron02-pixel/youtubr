import bpy,os
P='/workspace/THE_UNHAPPENED_BUREAU/CASE_001'
source=bpy.context.scene;source.name='01 • ANIMATED STREET'
edit=bpy.data.scenes.new('02 • FINAL EDIT');edit.frame_start=1;edit.frame_end=2520;edit.render.fps=24;edit.render.resolution_x=1080;edit.render.resolution_y=1920;edit.render.resolution_percentage=100
seq=edit.sequence_editor_create();seqs=seq.sequences
strip=seqs.new_scene('Animated street | 00:00–01:37',source,1,1);strip.frame_final_duration=2328
for n,a,b in [('hook',30,121),('timer',385,505),('failed',1153,1249),('question',2233,2329),('endcard',2329,2521)]:
 o=seqs.new_image(n,P+'/QA/'+n+'.png',2,a);o.frame_final_duration=b-a;o.blend_type='ALPHA_OVER'
seqs.new_sound('Original sound design',P+'/AUDIO/CASE_001_ORIGINAL_MIX.wav',3,1)
edit.render.image_settings.file_format='FFMPEG';edit.render.ffmpeg.format='MPEG4';edit.render.ffmpeg.codec='H264';edit.render.ffmpeg.audio_codec='AAC';edit.render.filepath='//../FINAL/CASE_001_EDIT_EXPORT.mp4'
# Preserve a useful 3D opening view; the second scene contains editable assembly.
source.frame_set(48)
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA'
bpy.ops.file.make_paths_relative()
bpy.ops.wm.save_as_mainfile(filepath=P+'/BLENDER/CASE_001_MASTER.blend')
